var app = new PIXI.Application({
	transparent: true,
});

// setting up canvas with css
app.renderer.view.style.position = "fixed";
app.renderer.view.style.display = "block";
app.renderer.autoResize = true;
app.renderer.resize(window.innerWidth, window.innerHeight);


// Draw rectangle for apply filter
var rect = new PIXI.Graphics()
    .beginFill(0x000000, 0.45) // Color, alpha
    .drawRect(0, 0, window.innerWidth, window.innerHeight)


// Anim noise effect
window.setInterval(animNoise, 0.7);
function animNoise() {
	// rect.filters = [new PIXI.filters.NoiseFilter(0.20, Math.random())];
	rect.filters = [new PIXI.filters.NoiseFilter(1, Math.random())];
}


// Update size on screen resize
window.addEventListener('resize', function() {
	app.renderer.resize(window.innerWidth, window.innerHeight);
	rect.height = window.innerHeight;
	rect.width = window.innerWidth;
});


// render app
app.stage.addChild(rect);
document.body.appendChild(app.view);




